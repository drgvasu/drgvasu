// sendLead.js (Node, for Vercel / Netlify)
const sgMail = require('@sendgrid/mail')
const { appendFileSync } = require('fs')
sgMail.setApiKey(process.env.SENDGRID_API_KEY)

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })
  const { name, email, phone, source, page, utm } = req.body || {}
  if (!email || !name) return res.status(400).json({ error: 'Missing name or email' })

  // Email owner
  const msg = {
    to: process.env.LEAD_RECEIVER_EMAIL,
    from: process.env.LEAD_SENDER || 'no-reply@yourdomain.com',
    subject: `New Lead: ${name} — ${source||'website'}`,
    html: `<p><strong>${name}</strong></p><p>Email: ${email}</p><p>Phone: ${phone||'-'}</p><p>Source: ${source}</p><p>Page: ${page}</p><pre>${JSON.stringify(utm || {}, null, 2)}</pre>`
  }

  try {
    await sgMail.send(msg)
    // Append to a CSV file (serverless ephemeral — if you need persistence, push to Google Sheets or a DB)
    const csvLine = `"${new Date().toISOString()}","${name.replace(/"/g,'') }","${email}","${phone||''}","${source||''}","${JSON.stringify(utm||{})}"\n`
    try { appendFileSync('/tmp/leads.csv', csvLine) } catch(e){ /* ignore */ }

    return res.status(200).json({ ok: true })
  } catch (err) {
    console.error('sendLead error', err)
    return res.status(500).json({ error: 'send error' })
  }
}
