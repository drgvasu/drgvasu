DV Analytics — Website Package
==============================

Files included:
- index.html                  : Main site file.
- api/sendLead.js             : Serverless function for Vercel/Netlify (SendGrid integration).
- assets/dvanalytics-main-logo.png : Logo (copied from your upload if available).
- assets/brochure-dv-analytics.pdf : Placeholder brochure (replace with real PDF).

Quick start:
1. Edit index.html to set GA_MEASUREMENT_ID, PIXEL_ID and your Formspree endpoint or SERVERLESS_ENDPOINT.
2. Replace assets/brochure-dv-analytics.pdf with your actual brochure PDF.
3. Deploy static site to Netlify / Vercel (drag & drop or Git).
4. If using sendLead.js, deploy on Vercel or Netlify functions and set environment variables:
   - SENDGRID_API_KEY
   - LEAD_RECEIVER_EMAIL
   - (optional) LEAD_SENDER
5. Test forms and brochure download.

If you want, I can:
- Replace the placeholder brochure with a real PDF (upload it).
- Fill in your tracking IDs and form endpoints.
- Create a GitHub repo and push these files for you.
